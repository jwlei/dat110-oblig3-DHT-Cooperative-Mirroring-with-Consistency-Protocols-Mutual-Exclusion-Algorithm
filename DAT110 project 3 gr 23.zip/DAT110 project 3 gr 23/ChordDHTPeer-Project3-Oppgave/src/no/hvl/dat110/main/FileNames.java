/**
 * 
 */
package no.hvl.dat110.main;

/**
 * @author tdoy
 *
 */
public enum FileNames {
	
	file1,
	file2,
	file3,
	file4,
	file5,
	file6,
	file7,
	file8

}
